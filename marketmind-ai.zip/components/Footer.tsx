
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-slate-200 mt-20">
      <div className="max-w-7xl mx-auto px-6 py-12 grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <h3 className="text-lg font-bold text-indigo-600 mb-4">MarketMind AI</h3>
          <p className="text-slate-500 text-sm leading-relaxed">
            The ultimate intelligence platform for modern marketing and sales teams. 
            Empower your strategy with real-time AI insights.
          </p>
        </div>
        <div>
          <h4 className="font-semibold text-slate-900 mb-4">Product</h4>
          <ul className="space-y-2 text-sm text-slate-500">
            <li><a href="#" className="hover:text-indigo-600">Features</a></li>
            <li><a href="#" className="hover:text-indigo-600">Pricing</a></li>
            <li><a href="#" className="hover:text-indigo-600">API Documentation</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold text-slate-900 mb-4">Company</h4>
          <ul className="space-y-2 text-sm text-slate-500">
            <li><a href="#" className="hover:text-indigo-600">About Us</a></li>
            <li><a href="#" className="hover:text-indigo-600">Contact Support</a></li>
            <li><a href="#" className="hover:text-indigo-600">Privacy Policy</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-slate-100 py-6 text-center text-xs text-slate-400">
        © {new Date().getFullYear()} MarketMind AI. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;
