
import React, { useState } from 'react';
import { analyzeMarket } from '../services/geminiService';
import { MarketAnalysisResult } from '../types';

const MarketAnalysis: React.FC = () => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<MarketAnalysisResult | null>(null);

  const handleGenerate = async () => {
    if (!input.trim()) return;
    setLoading(true);
    try {
      const data = await analyzeMarket(input);
      setResult(data);
    } catch (error) {
      console.error(error);
      alert('Failed to analyze market.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-6 py-12">
      <div className="mb-8 text-center">
        <h2 className="text-3xl font-bold text-slate-900">Market Intelligence</h2>
        <p className="text-slate-500">Analyze industries, competitors, or emerging trends with Gemini Pro.</p>
      </div>

      <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 mb-10 max-w-2xl mx-auto">
        <label className="block text-sm font-semibold text-slate-700 mb-2">Industry or Trend to Analyze</label>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="e.g., The vertical farming industry in Europe 2024-2026"
          className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 outline-none transition-all mb-4"
        />
        <button
          onClick={handleGenerate}
          disabled={loading || !input}
          className={`w-full py-4 rounded-xl font-bold text-white transition-all ${
            loading ? 'bg-purple-300 cursor-not-allowed' : 'bg-purple-600 hover:bg-purple-700 active:scale-[0.98]'
          }`}
        >
          {loading ? 'Gathering market data...' : 'Run Deep Analysis'}
        </button>
      </div>

      {result && (
        <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="bg-purple-50 p-8 rounded-[2.5rem] border border-purple-100">
            <h3 className="text-2xl font-bold text-purple-900 mb-4">Executive Summary</h3>
            <p className="text-slate-700 leading-relaxed text-lg">{result.summary}</p>
          </div>

          <div>
            <h4 className="text-xl font-bold text-slate-900 mb-6">Trending Drivers</h4>
            <div className="overflow-x-auto rounded-3xl border border-slate-100">
              <table className="w-full text-left bg-white">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-6 py-4 font-bold text-slate-700 text-sm">Trend</th>
                    <th className="px-6 py-4 font-bold text-slate-700 text-sm">Market Impact</th>
                    <th className="px-6 py-4 font-bold text-slate-700 text-sm">Actionable Opportunity</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {result.trends.map((t, idx) => (
                    <tr key={idx} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 font-semibold text-slate-900">{t.trend}</td>
                      <td className="px-6 py-4 text-slate-600 text-sm">{t.impact}</td>
                      <td className="px-6 py-4 text-purple-600 text-sm font-medium">{t.opportunity}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <div className="bg-white p-6 rounded-3xl border border-slate-100">
                <h4 className="font-bold text-green-600 mb-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-green-500"></span> Strengths
                </h4>
                <ul className="space-y-2">
                  {result.swot.strengths.map((s, idx) => <li key={idx} className="text-sm text-slate-600">• {s}</li>)}
                </ul>
             </div>
             <div className="bg-white p-6 rounded-3xl border border-slate-100">
                <h4 className="font-bold text-red-600 mb-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-red-500"></span> Weaknesses
                </h4>
                <ul className="space-y-2">
                  {result.swot.weaknesses.map((s, idx) => <li key={idx} className="text-sm text-slate-600">• {s}</li>)}
                </ul>
             </div>
             <div className="bg-white p-6 rounded-3xl border border-slate-100">
                <h4 className="font-bold text-blue-600 mb-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-blue-500"></span> Opportunities
                </h4>
                <ul className="space-y-2">
                  {result.swot.opportunities.map((s, idx) => <li key={idx} className="text-sm text-slate-600">• {s}</li>)}
                </ul>
             </div>
             <div className="bg-white p-6 rounded-3xl border border-slate-100">
                <h4 className="font-bold text-orange-600 mb-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-orange-500"></span> Threats
                </h4>
                <ul className="space-y-2">
                  {result.swot.threats.map((s, idx) => <li key={idx} className="text-sm text-slate-600">• {s}</li>)}
                </ul>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MarketAnalysis;
