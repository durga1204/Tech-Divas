
import React, { useState } from 'react';
import { generateCampaign } from '../services/geminiService';
import { CampaignResult } from '../types';

const Campaign: React.FC = () => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<CampaignResult | null>(null);

  const handleGenerate = async () => {
    if (!input.trim()) return;
    setLoading(true);
    try {
      const data = await generateCampaign(input);
      setResult(data);
    } catch (error) {
      console.error(error);
      alert('Failed to generate campaign. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-12">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-slate-900">Campaign Generator</h2>
        <p className="text-slate-500">Describe your product or campaign idea to get a full marketing plan.</p>
      </div>

      <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 mb-10">
        <label className="block text-sm font-semibold text-slate-700 mb-2">Product or Campaign Concept</label>
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="e.g., A subscription service for sustainable office plants targeted at tech startups."
          className="w-full h-32 p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all resize-none mb-4"
        />
        <button
          onClick={handleGenerate}
          disabled={loading || !input}
          className={`w-full py-4 rounded-xl font-bold text-white transition-all ${
            loading ? 'bg-indigo-300 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98]'
          }`}
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              AI is brainstorming...
            </span>
          ) : (
            'Generate Full Campaign'
          )}
        </button>
      </div>

      {result && (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="bg-indigo-50 border border-indigo-100 p-8 rounded-3xl">
            <h3 className="text-2xl font-bold text-indigo-900 mb-2">{result.title}</h3>
            <p className="text-indigo-600 font-medium italic mb-6">"{result.tagline}"</p>
            
            <div className="space-y-6">
              <div>
                <h4 className="font-bold text-indigo-900 mb-2 uppercase text-xs tracking-wider">Campaign Copy</h4>
                <div className="bg-white p-6 rounded-2xl border border-indigo-100 text-slate-700 leading-relaxed whitespace-pre-wrap">
                  {result.copy}
                </div>
              </div>
              
              <div>
                <h4 className="font-bold text-indigo-900 mb-2 uppercase text-xs tracking-wider">Recommended Channels</h4>
                <div className="flex flex-wrap gap-2">
                  {result.channels.map((ch, idx) => (
                    <span key={idx} className="px-4 py-2 bg-white border border-indigo-100 text-indigo-600 rounded-full text-sm font-semibold">
                      {ch}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Campaign;
