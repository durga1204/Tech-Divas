
import React from 'react';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
  const features = [
    {
      title: 'Generate Campaign',
      desc: 'Create end-to-end marketing campaigns including taglines and copy in seconds.',
      icon: '🚀',
      link: '/campaign',
      color: 'bg-blue-50 text-blue-600'
    },
    {
      title: 'Sales Pitch',
      desc: 'Craft persuasive sales pitches tailored to specific prospect pain points.',
      icon: '🎯',
      link: '/pitch',
      color: 'bg-indigo-50 text-indigo-600'
    },
    {
      title: 'Analyze Leads',
      desc: 'Score your leads and discover the best strategy to close the deal.',
      icon: '⚡',
      link: '/leads',
      color: 'bg-teal-50 text-teal-600'
    },
    {
      title: 'Market Insights',
      desc: 'Get deep industry trends and competitive SWOT analysis instantly.',
      icon: '📊',
      link: '/market',
      color: 'bg-purple-50 text-purple-600'
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <div className="text-center mb-16">
        <h1 className="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
          Supercharge your <span className="text-indigo-600">GTM Strategy</span>
        </h1>
        <p className="text-xl text-slate-600 max-w-2xl mx-auto mb-10">
          MarketMind AI uses the power of Gemini to transform how you generate campaigns, analyze leads, and understand your market.
        </p>
        <div className="flex justify-center gap-4">
          <Link to="/campaign" className="px-8 py-3 bg-indigo-600 text-white font-semibold rounded-full hover:bg-indigo-700 transition shadow-lg shadow-indigo-200">
            Get Started
          </Link>
          <button className="px-8 py-3 bg-white text-slate-600 font-semibold border border-slate-200 rounded-full hover:bg-slate-50 transition">
            View Demo
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {features.map((f, i) => (
          <Link
            key={i}
            to={f.link}
            className="group p-8 bg-white border border-slate-100 rounded-3xl hover:border-indigo-100 hover:shadow-xl hover:shadow-indigo-50 transition-all"
          >
            <div className={`w-12 h-12 rounded-2xl ${f.color} flex items-center justify-center text-2xl mb-6 group-hover:scale-110 transition-transform`}>
              {f.icon}
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-3">{f.title}</h3>
            <p className="text-slate-500 text-sm leading-relaxed mb-6">
              {f.desc}
            </p>
            <div className="text-indigo-600 font-semibold text-sm flex items-center gap-2 group-hover:gap-3 transition-all">
              Learn more <span>→</span>
            </div>
          </Link>
        ))}
      </div>

      <div className="mt-20 p-12 bg-indigo-900 rounded-[3rem] text-center text-white">
        <h2 className="text-3xl font-bold mb-4">Ready to revolutionize your workflow?</h2>
        <p className="text-indigo-100 mb-8 max-w-lg mx-auto">
          Join 500+ teams using MarketMind to scale their outbound and marketing operations.
        </p>
        <Link to="/leads" className="inline-block px-10 py-4 bg-white text-indigo-900 font-bold rounded-full hover:bg-slate-100 transition">
          Analyze Your First Lead
        </Link>
      </div>
    </div>
  );
};

export default Home;
