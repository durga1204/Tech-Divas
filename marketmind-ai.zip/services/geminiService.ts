
import { GoogleGenAI, Type } from "@google/genai";
import { CampaignResult, PitchResult, LeadAnalysis, MarketAnalysisResult } from "../types";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateCampaign = async (input: string): Promise<CampaignResult> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Generate a full marketing campaign for: ${input}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          tagline: { type: Type.STRING },
          copy: { type: Type.STRING },
          channels: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ["title", "tagline", "copy", "channels"],
      },
    },
  });
  return JSON.parse(response.text || '{}');
};

export const generateSalesPitch = async (input: string): Promise<PitchResult> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Create a persuasive sales pitch for: ${input}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          hook: { type: Type.STRING },
          solution: { type: Type.STRING },
          callToAction: { type: Type.STRING },
        },
        required: ["hook", "solution", "callToAction"],
      },
    },
  });
  return JSON.parse(response.text || '{}');
};

export const analyzeLead = async (input: string): Promise<LeadAnalysis> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze this lead and provide a score (0-100), priority level, and strategic advice: ${input}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          score: { type: Type.NUMBER },
          priority: { type: Type.STRING },
          strategy: { type: Type.STRING },
          insights: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ["score", "priority", "strategy", "insights"],
      },
    },
  });
  return JSON.parse(response.text || '{}');
};

export const analyzeMarket = async (input: string): Promise<MarketAnalysisResult> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Provide an in-depth market analysis and SWOT for: ${input}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING },
          trends: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                trend: { type: Type.STRING },
                impact: { type: Type.STRING },
                opportunity: { type: Type.STRING },
              },
            },
          },
          swot: {
            type: Type.OBJECT,
            properties: {
              strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
              weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
              opportunities: { type: Type.ARRAY, items: { type: Type.STRING } },
              threats: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
          },
        },
        required: ["summary", "trends", "swot"],
      },
    },
  });
  return JSON.parse(response.text || '{}');
};
