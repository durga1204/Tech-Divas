
import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Campaign from './pages/Campaign';
import SalesPitch from './pages/SalesPitch';
import LeadInsights from './pages/LeadInsights';
import MarketAnalysis from './pages/MarketAnalysis';

const App: React.FC = () => {
  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/campaign" element={<Campaign />} />
            <Route path="/pitch" element={<SalesPitch />} />
            <Route path="/leads" element={<LeadInsights />} />
            <Route path="/market" element={<MarketAnalysis />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
};

export default App;
