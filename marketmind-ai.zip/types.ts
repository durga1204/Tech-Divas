
export interface CampaignResult {
  title: string;
  tagline: string;
  copy: string;
  channels: string[];
}

export interface PitchResult {
  hook: string;
  solution: string;
  callToAction: string;
}

export interface LeadAnalysis {
  score: number;
  priority: 'High' | 'Medium' | 'Low';
  strategy: string;
  insights: string[];
}

export interface MarketInsight {
  trend: string;
  impact: string;
  opportunity: string;
}

export interface MarketAnalysisResult {
  summary: string;
  trends: MarketInsight[];
  swot: {
    strengths: string[];
    weaknesses: string[];
    opportunities: string[];
    threats: string[];
  };
}
