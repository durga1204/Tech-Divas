
import React, { useState } from 'react';
import { generateSalesPitch } from '../services/geminiService';
import { PitchResult } from '../types';

const SalesPitch: React.FC = () => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<PitchResult | null>(null);

  const handleGenerate = async () => {
    if (!input.trim()) return;
    setLoading(true);
    try {
      const data = await generateSalesPitch(input);
      setResult(data);
    } catch (error) {
      console.error(error);
      alert('Failed to generate pitch.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-12">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-slate-900">Sales Pitch Builder</h2>
        <p className="text-slate-500">Tailor your value proposition to a specific customer persona or pain point.</p>
      </div>

      <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 mb-10">
        <label className="block text-sm font-semibold text-slate-700 mb-2">Customer Persona / Product Info</label>
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="e.g., Pitching an AI-based legal assistant to a boutique law firm struggling with document overflow."
          className="w-full h-32 p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all resize-none mb-4"
        />
        <button
          onClick={handleGenerate}
          disabled={loading || !input}
          className={`w-full py-4 rounded-xl font-bold text-white transition-all ${
            loading ? 'bg-blue-300 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 active:scale-[0.98]'
          }`}
        >
          {loading ? 'Crafting the perfect pitch...' : 'Generate Sales Pitch'}
        </button>
      </div>

      {result && (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
              <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">The Hook</h4>
              <p className="text-lg font-medium text-slate-800 leading-relaxed italic">"{result.hook}"</p>
            </div>
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
              <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Call to Action</h4>
              <p className="text-lg font-medium text-blue-600 leading-relaxed">{result.callToAction}</p>
            </div>
          </div>
          <div className="bg-blue-600 text-white p-8 rounded-3xl shadow-lg shadow-blue-200">
            <h4 className="text-xs font-bold text-blue-200 uppercase tracking-widest mb-4">The core solution</h4>
            <p className="text-xl leading-relaxed font-light">{result.solution}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default SalesPitch;
