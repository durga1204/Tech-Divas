
import React, { useState } from 'react';
import { analyzeLead } from '../services/geminiService';
import { LeadAnalysis } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

const LeadInsights: React.FC = () => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<LeadAnalysis | null>(null);

  const handleGenerate = async () => {
    if (!input.trim()) return;
    setLoading(true);
    try {
      const data = await analyzeLead(input);
      setResult(data);
    } catch (error) {
      console.error(error);
      alert('Failed to analyze lead.');
    } finally {
      setLoading(false);
    }
  };

  const chartData = result ? [
    { name: 'Lead Score', value: result.score },
    { name: 'Gap', value: 100 - result.score },
  ] : [];

  const COLORS = ['#4f46e5', '#f1f5f9'];

  return (
    <div className="max-w-4xl mx-auto px-6 py-12">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-slate-900">Lead Intelligence</h2>
        <p className="text-slate-500">Input lead data (LinkedIn bio, website, company size) to get a closing strategy.</p>
      </div>

      <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 mb-10">
        <label className="block text-sm font-semibold text-slate-700 mb-2">Lead Information</label>
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Paste lead details or company profile here..."
          className="w-full h-32 p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 outline-none transition-all resize-none mb-4"
        />
        <button
          onClick={handleGenerate}
          disabled={loading || !input}
          className={`w-full py-4 rounded-xl font-bold text-white transition-all ${
            loading ? 'bg-teal-300 cursor-not-allowed' : 'bg-teal-600 hover:bg-teal-700 active:scale-[0.98]'
          }`}
        >
          {loading ? 'Analyzing prospects...' : 'Score Lead'}
        </button>
      </div>

      {result && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="md:col-span-1 bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex flex-col items-center justify-center">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Lead Score</h4>
            <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={chartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                    startAngle={90}
                    endAngle={-270}
                  >
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none mt-16">
                 <span className="text-4xl font-bold text-slate-800">{result.score}</span>
                 <span className={`text-sm font-bold px-2 py-0.5 rounded ${
                   result.priority === 'High' ? 'bg-green-100 text-green-700' : 
                   result.priority === 'Medium' ? 'bg-yellow-100 text-yellow-700' : 'bg-slate-100 text-slate-700'
                 }`}>
                   {result.priority} Priority
                 </span>
              </div>
            </div>
          </div>

          <div className="md:col-span-2 space-y-6">
            <div className="bg-teal-50 border border-teal-100 p-6 rounded-3xl">
              <h4 className="text-sm font-bold text-teal-700 uppercase mb-4">Closing Strategy</h4>
              <p className="text-slate-800 leading-relaxed">{result.strategy}</p>
            </div>
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
              <h4 className="text-sm font-bold text-slate-400 uppercase mb-4">Key Insights</h4>
              <ul className="space-y-3">
                {result.insights.map((insight, idx) => (
                  <li key={idx} className="flex gap-3 text-slate-600 text-sm">
                    <span className="text-teal-500">✓</span>
                    {insight}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LeadInsights;
